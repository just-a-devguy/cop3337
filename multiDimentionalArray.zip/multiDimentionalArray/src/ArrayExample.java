/* Just an introduction to Array that how we define Arrays*/
public class ArrayExample {

    public static void main(String[] args) {

        int[] numbers=new int[5]; // declaring array
        numbers[0]=5; // assigning value to the array index 0
        numbers[4]=10; // assigning value to the array index 4

        System.out.println(numbers[2]); // print the values of array
   }

}
